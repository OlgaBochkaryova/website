---
title: "Contact"
---

**e-mail:** *olga.bochkareva@ist.ac.at*

**address:** Am Campus 1, Klosterneuburg, Austria, 3400, IST Austria

**Web page:** [current lab](https://ist.ac.at/en/research/kondrashov-group/)

**ORCID:** 	0000-0003-1006-6639 [(profile)](https://orcid.org/0000-0003-1006-6639)
